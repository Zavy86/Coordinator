<?php
/* -[ Redirect to index ]---------------------------------------------------- */
header("location: ../index.php");
?>